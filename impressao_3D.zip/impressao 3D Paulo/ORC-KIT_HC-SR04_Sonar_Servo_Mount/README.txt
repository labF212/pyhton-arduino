                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2004301
ORC-KIT HC-SR04 Sonar Servo Mount by battlecoder is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This <b>Sonar Mount</b> is part of the <b>ORC-KIT</b> project. The 3D model and Sketch-up file can also be obtained from the <a href="https://github.com/battlecoder/orc-kit" target="_blank">project Github repository</a>. I'll try to keep the files here perfectly in sync with any update to the repo, so you'll always get the latest version.

Visit the <a href="http://damnsoft.org/orc-kit" target="_blank">ORC-KIT Page</a> for more information.

<b>[!]</b> IMPORTANT:Read Post-Printing instructions!

# Post-Printing

## May need sanding

The two pieces that make this sonar mount are designed for a <b>tight</b> fit.

Since the "sharpness" and precision of the actual parts will depend on the 3D printer settings and quality, I made the 3D models with <b>zero</b> space between the two parts.

This means that unless your printer has nearly atomic precision, you will need to sand down the "tabs" of each side with a needle file, a Dremel tool or a hobby knife, before the two parts fit together.